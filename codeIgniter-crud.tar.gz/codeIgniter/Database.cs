using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Testing
{
    #region Testing
    public class Testing
    {
        #region Member Variables
        protected int _id;
        protected string _name;
        protected string _mobile;
        protected string _email;
        protected string _file_name;
        protected unknown _date_entered;
        protected DateTime _date_modified;
        protected string _users_ip;
        #endregion
        #region Constructors
        public Testing() { }
        public Testing(string name, string mobile, string email, string file_name, unknown date_entered, DateTime date_modified, string users_ip)
        {
            this._name=name;
            this._mobile=mobile;
            this._email=email;
            this._file_name=file_name;
            this._date_entered=date_entered;
            this._date_modified=date_modified;
            this._users_ip=users_ip;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Name
        {
            get {return _name;}
            set {_name=value;}
        }
        public virtual string Mobile
        {
            get {return _mobile;}
            set {_mobile=value;}
        }
        public virtual string Email
        {
            get {return _email;}
            set {_email=value;}
        }
        public virtual string File_name
        {
            get {return _file_name;}
            set {_file_name=value;}
        }
        public virtual unknown Date_entered
        {
            get {return _date_entered;}
            set {_date_entered=value;}
        }
        public virtual DateTime Date_modified
        {
            get {return _date_modified;}
            set {_date_modified=value;}
        }
        public virtual string Users_ip
        {
            get {return _users_ip;}
            set {_users_ip=value;}
        }
        #endregion
    }
    #endregion
}